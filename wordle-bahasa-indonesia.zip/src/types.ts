export type ColorState = 'correct' | 'present' | 'absent' | 'empty';

export interface Guess {
  word: string;
  colors: ColorState[];
}

export interface VoteData {
  [word: string]: number;
}

export interface Guesser {
  uniqueId: string;
  nickname: string;
  profilePictureUrl: string;
}

export interface FirstGuessers {
  [word: string]: Guesser;
}

