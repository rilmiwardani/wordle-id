import React, { useState, useEffect } from 'react';
import { Grid } from './components/Grid';
import { VotingUI } from './components/VotingUI';
import { useTikTokLive } from './hooks/useTikTokLive';
import { Guess, Guesser } from './types';
import { getRandomWord, evaluateGuess } from './utils/gameLogic';
import { RefreshCcw, Tv } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const VOTING_TIME = 30;
const AVAILABLE_LENGTHS = [4, 5, 6, 7, 8, 9];

export default function App() {
  const [wordLength, setWordLength] = useState<number>(5);
  const [showLengthMenu, setShowLengthMenu] = useState<boolean>(false);
  const [targetWord, setTargetWord] = useState<string>('');
  const [guesses, setGuesses] = useState<Guess[]>([]);
  const [currentRow, setCurrentRow] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(VOTING_TIME);
  const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');
  const [fastestGuesser, setFastestGuesser] = useState<Guesser | null>(null);

  const [currentStreak, setCurrentStreak] = useState<number>(() => {
    const saved = localStorage.getItem('wordleCurrentStreak');
    return saved ? parseInt(saved, 10) : 0;
  });
  const [bestStreak, setBestStreak] = useState<number>(() => {
    const saved = localStorage.getItem('wordleBestStreak');
    return saved ? parseInt(saved, 10) : 0;
  });

  useEffect(() => {
    localStorage.setItem('wordleCurrentStreak', currentStreak.toString());
    localStorage.setItem('wordleBestStreak', bestStreak.toString());
  }, [currentStreak, bestStreak]);

  const { votes, firstGuessers, clearVotes, isConnected } = useTikTokLive(gameState === 'playing', wordLength);

  const initGame = (prevWinningWord?: string, forceLength?: number) => {
    const activeLength = forceLength || wordLength;
    const newTarget = getRandomWord(activeLength);
    setTargetWord(newTarget);
    
    // Baris pertama diisi otomatis dari kata pemenang sebelumnya (jika panjang kata sesuai) atau acak
    const initialGuessWord = (prevWinningWord && prevWinningWord.length === activeLength) 
      ? prevWinningWord 
      : getRandomWord(activeLength);
      
    const evaluatedColors = evaluateGuess(initialGuessWord, newTarget);
    
    setGuesses([
      { word: initialGuessWord, colors: evaluatedColors }
    ]);
    setCurrentRow(1);
    setTimeLeft(VOTING_TIME);
    setGameState('playing');
    setFastestGuesser(null);
    clearVotes();
  };

  // Init on mount or when word length changes
  useEffect(() => {
    initGame(undefined, wordLength);
  }, [wordLength]);

  // Timer Tick
  useEffect(() => {
    if (gameState !== 'playing') return;

    if (timeLeft > 0) {
      const timerId = window.setTimeout(() => {
        setTimeLeft(prv => prv - 1);
      }, 1000);
      return () => clearTimeout(timerId);
    } else {
      handleRoundEnd();
    }
  }, [timeLeft, gameState]);

  // Auto Restart
  useEffect(() => {
    if (gameState !== 'playing') {
      const timerId = window.setTimeout(() => {
        initGame(gameState === 'won' ? guesses[guesses.length - 1]?.word : undefined);
      }, 7000); // 7 seconds
      return () => clearTimeout(timerId);
    }
  }, [gameState, guesses, wordLength]);

  const handleRoundEnd = () => {
    const sortedVotes = Object.entries(votes).sort((a, b) => (b[1] as number) - (a[1] as number));
    
    if (sortedVotes.length === 0) {
      setTimeLeft(VOTING_TIME);
      return;
    }
    
    const topVotedWord = sortedVotes[0][0];

    const colors = evaluateGuess(topVotedWord, targetWord);
    const newGuesses = [...guesses, { word: topVotedWord, colors }];
    setGuesses(newGuesses);
    
    const isWin = topVotedWord === targetWord;
    
    // Save fastest guesser before clearing votes
    if (isWin && firstGuessers[topVotedWord]) {
      setFastestGuesser(firstGuessers[topVotedWord]);
    }
    
    clearVotes();
    
    if (isWin) {
      setGameState('won');
      setCurrentStreak(prev => {
        const newStreak = prev + 1;
        setBestStreak(currentBest => Math.max(currentBest, newStreak));
        return newStreak;
      });
    } else if (newGuesses.length >= 5) {
      setGameState('lost');
      setCurrentStreak(0);
    } else {
      setCurrentRow(prev => prev + 1);
      setTimeLeft(VOTING_TIME);
    }
  };

  const restartGame = () => {
    initGame(gameState === 'won' ? guesses[guesses.length - 1].word : undefined);
  };

  return (
    <div className="wordle-container">
      
      {/* Header */}
      <div className="flex flex-col items-center justify-center mb-8 w-full text-center">
        <h1 className="text-4xl sm:text-5xl font-black tracking-widest text-white mb-2">
          WORDLE.ID
        </h1>
        <div className="flex items-center justify-center gap-3 mt-1 w-full">
          <div className="text-slate-400 text-sm flex items-center justify-center gap-1.5 relative">
            Kirim 
            <div className="relative">
              <button 
                onClick={() => setShowLengthMenu(!showLengthMenu)}
                className="font-bold text-white hover:text-blue-400 transition-colors border-b border-dashed border-slate-500 hover:border-blue-400 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/50 rounded"
              >
                {wordLength} huruf
              </button>
              
              <AnimatePresence>
                {showLengthMenu && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 5, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-[#1e293b] border border-slate-700/80 rounded-xl shadow-2xl z-50 flex flex-col p-1.5 min-w-[100px]"
                  >
                    {AVAILABLE_LENGTHS.map(len => (
                      <button
                        key={len}
                        onClick={() => {
                          setWordLength(len);
                          setShowLengthMenu(false);
                        }}
                        className={`text-xs px-3 py-2 whitespace-nowrap rounded-lg text-center transition-all ${
                          len === wordLength 
                            ? 'bg-blue-500/20 text-blue-400 font-bold' 
                            : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
                        }`}
                      >
                        {len} Huruf
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            di chat untuk voting!
          </div>
        </div>
      </div>

      {/* Main Game Area */}
      <div className="flex-1 flex flex-col relative w-full items-center">
        {/* Streak Display */}
        <div className="w-full max-w-md mx-auto mb-4 flex justify-center gap-4">
          <div className="flex bg-slate-800/50 rounded-full px-4 py-1.5 border border-slate-700/50 shadow-inner items-center gap-2">
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Streak</span>
            <span className="text-sm font-black text-amber-400">{currentStreak}</span>
          </div>
          <div className="flex bg-slate-800/50 rounded-full px-4 py-1.5 border border-slate-700/50 shadow-inner items-center gap-2">
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Best</span>
            <span className="text-sm font-black text-white">{bestStreak}</span>
          </div>
        </div>

        {/* Minimalist Time Bar */}
        <div className="w-full max-w-md mx-auto mb-6">
          <div className="flex justify-between items-end mb-2">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold">Waktu Voting</span>
            <span className={`text-sm font-mono font-bold ${gameState === 'playing' ? 'text-blue-400' : 'text-slate-500'}`}>00:{timeLeft.toString().padStart(2, '0')}</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800/50 rounded-full overflow-hidden shadow-inner">
            <motion.div 
              className={`h-full ${gameState === 'playing' ? 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.3)]' : 'bg-slate-600'}`}
              initial={{ width: '100%' }}
              animate={{ width: `${(timeLeft / VOTING_TIME) * 100}%` }}
              transition={{ duration: 1, ease: 'linear' }}
            />
          </div>
        </div>

        <Grid guesses={guesses} currentRow={currentRow} wordLength={wordLength} />

        {/* Overlay for Win/Loss Result */}
        <AnimatePresence>
          {gameState !== 'playing' && (
            <motion.div 
              initial={{ opacity: 0, backdropFilter: 'blur(0px)' }}
              animate={{ opacity: 1, backdropFilter: 'blur(12px)' }}
              exit={{ opacity: 0, backdropFilter: 'blur(0px)' }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/80 rounded-xl p-4 text-center overflow-hidden"
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.8, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 20 }}
                transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="bg-slate-900/90 p-8 rounded-3xl border border-slate-700 shadow-[0_0_50px_rgba(0,0,0,0.5)] max-w-sm w-full mx-auto"
              >
                <motion.h2 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
                  className={`text-3xl font-extrabold mb-2 uppercase tracking-wide ${gameState === 'won' ? 'text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.4)]' : 'text-red-400 drop-shadow-[0_0_15px_rgba(248,113,113,0.4)]'}`}
                >
                  {gameState === 'won' ? 'BERHASIL HACK!' : 'GAGAL MENEBAK'}
                </motion.h2>
                
                {gameState === 'lost' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="text-slate-300 mt-6 mb-6"
                  >
                    <span className="block text-sm uppercase tracking-wider text-slate-500 mb-2">Kata rahasia:</span>
                    <span className="font-mono text-4xl font-bold text-white tracking-[0.2em] block drop-shadow-[0_0_8px_rgba(255,255,255,0.3)] bg-slate-800/80 py-3 rounded-xl border border-slate-700/80">
                      {targetWord}
                    </span>
                  </motion.div>
                )}
                
                {gameState === 'won' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="text-slate-300 mt-4 mb-6 text-sm"
                  >
                    Kalian menebak dengan benar! Kata ini akan menjadi clue di ronde selanjutnya.
                    
                    {fastestGuesser && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.8, type: "spring" }}
                        className="mt-5 flex flex-col items-center bg-slate-800/80 rounded-2xl p-4 border border-emerald-500/30 shadow-[0_0_20px_rgba(52,211,153,0.1)] relative overflow-hidden"
                      >
                        {/* Shine effect */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-emerald-400/10 to-transparent opacity-0 animate-[shimmer_2s_infinite]" />
                        
                        <span className="text-[10px] uppercase tracking-widest text-emerald-400 mb-3 font-bold">Penebak Tercepat</span>
                        <div className="flex items-center gap-4 z-10">
                          {fastestGuesser.profilePictureUrl ? (
                            <img src={fastestGuesser.profilePictureUrl} alt={fastestGuesser.nickname} className="w-12 h-12 rounded-full border-2 border-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.4)]" />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center font-bold text-xl text-white border-2 border-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.4)]">
                              {fastestGuesser.nickname.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="flex items-center text-left">
                            <span className="font-black text-white text-lg tracking-tight">{fastestGuesser.nickname}</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                )}

                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1 }}
                  className="mt-8 relative"
                >
                  <div className="h-1.5 w-full bg-slate-800/80 rounded-full overflow-hidden shadow-inner">
                    <motion.div 
                      className="h-full bg-slate-500"
                      initial={{ width: '0%' }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 7, ease: 'linear' }}
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 uppercase mt-3 font-bold tracking-[0.2em]">
                    Memulai ronde baru...
                  </p>
                </motion.div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Live Voting Display */}
      {gameState === 'playing' ? (
        <VotingUI votes={votes} />
      ) : (
        <div className="mt-8 space-y-4 w-full opacity-50 pointer-events-none">
          <VotingUI votes={{}} />
        </div>
      )}
      
      {/* BRANDING / STATUS */}
      <div className="flex justify-between items-end mt-4 w-full">
          <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isConnected ? 'IndoFinity Stream Connected' : 'Disconnected (Simulation Mode)'}</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
              SESSION ID: IND-WORD-{Math.floor(Math.random() * 9000) + 1000}
          </div>
      </div>
      
    </div>
  );
}