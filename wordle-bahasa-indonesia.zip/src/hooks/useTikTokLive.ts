import { useState, useEffect, useRef } from 'react';
import { VoteData, FirstGuessers, Guesser } from '../types';
import { isValidWord, getRandomWord } from '../utils/gameLogic';

export function useTikTokLive(isActive: boolean, wordLength: number) {
  const [votes, setVotes] = useState<VoteData>({});
  const [firstGuessers, setFirstGuessers] = useState<FirstGuessers>({});
  const [isConnected, setIsConnected] = useState(false);

  const isActiveRef = useRef(isActive);
  const wordLengthRef = useRef(wordLength);

  useEffect(() => {
    isActiveRef.current = isActive;
    wordLengthRef.current = wordLength;
  }, [isActive, wordLength]);

  const handleIncomingComment = (comment: string, guesser?: Guesser) => {
    // Sanitize: remove non-alphabetic characters to bypass filters (e.g. B A C O K -> BACOK)
    const guessedWord = comment.replace(/[^a-zA-Z]/g, '').toUpperCase();
    const currentLength = wordLengthRef.current;
    
    if (guessedWord.length === currentLength && isValidWord(guessedWord, currentLength)) {
      setVotes(prev => ({
        ...prev,
        [guessedWord]: (prev[guessedWord] || 0) + 1
      }));
      
      if (guesser) {
        setFirstGuessers(prev => {
          if (!prev[guessedWord]) {
            return {
              ...prev,
              [guessedWord]: guesser
            };
          }
          return prev;
        });
      }
    }
  };

  useEffect(() => {
    let ws: WebSocket;

    const connectWS = () => {
      try {
        ws = new WebSocket('ws://localhost:62024');

        ws.onopen = () => {
          console.log('Terhubung ke IndoFinity WebSocket');
          setIsConnected(true);
        };

        ws.onmessage = (event) => {
          if (!isActiveRef.current) return;

          try {
            const message = JSON.parse(event.data);
            const { event: eventType, data: eventData } = message;

            if (eventType === 'chat') {
              console.log(`@${eventData.uniqueId}: ${eventData.comment}`);
              handleIncomingComment(eventData.comment || '', {
                uniqueId: eventData.uniqueId,
                nickname: eventData.nickname || eventData.uniqueId,
                profilePictureUrl: eventData.profilePictureUrl || ''
              });
            }
          } catch (error) {
            console.error('Error parsing message:', error);
          }
        };

        ws.onclose = () => {
          console.log('Koneksi WebSocket ditutup');
          setIsConnected(false);
          // Try to reconnect after 3 seconds
          setTimeout(connectWS, 3000);
        };

        ws.onerror = (err) => {
          console.error('WebSocket error:', err);
        };
      } catch (e) {
        console.error("Gagal memulai WebSocket", e);
      }
    };

    connectWS();

    return () => {
      if (ws) {
        ws.onclose = null; // Prevent reconnect on unmount
        ws.close();
      }
    };
  }, []);

  // --- SIMULATION LOGIC ---
  useEffect(() => {
    let interval: number;

    if (isActive && !isConnected) {
      // Simulate incoming comments every 500ms-1500ms
      interval = window.setInterval(() => {
        const isSpam = Math.random() > 0.7;
        const fakeComment = isSpam ? "spam komen ah" : getRandomWord(wordLength);
        
        handleIncomingComment(fakeComment);
      }, Math.random() * 800 + 400);
    }

    return () => clearInterval(interval);
  }, [isActive, isConnected, wordLength]);

  const clearVotes = () => {
    setVotes({});
    setFirstGuessers({});
  };

  return { votes, firstGuessers, handleIncomingComment, clearVotes, isConnected };
}
