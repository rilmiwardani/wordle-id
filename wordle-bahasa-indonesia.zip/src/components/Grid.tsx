import React from 'react';
import { Guess } from '../types';
import { motion } from 'motion/react';

interface GridProps {
  guesses: Guess[];
  currentRow: number;
  wordLength: number;
}

export function Grid({ guesses, currentRow, wordLength }: GridProps) {
  const rows = Array.from({ length: 5 });

  return (
    <motion.div 
      layout
      className="flex-1 flex flex-col items-center justify-center gap-3 w-full"
      style={{ '--tile-size': `min(80px, calc((100vw - 40px - (${wordLength} - 1) * 8px) / ${wordLength}))` } as React.CSSProperties}
    >
      {rows.map((_, i) => {
        const guess = guesses[i];
        const isCurrentRow = i === currentRow;
        const isPending = i > currentRow;

        return (
          <motion.div layout key={i} className={`flex gap-2 relative max-w-full ${isCurrentRow ? 'active-row p-2' : ''}`}>
            {Array.from({ length: wordLength }).map((_, j) => {
              const letter = guess ? guess.word[j] : '';
              const state = guess ? guess.colors[j] : 'empty';
              
              let tileClass = "tile";
              
              if (isCurrentRow) {
                 tileClass += " bg-transparent text-blue-300";
              } else if (state === 'correct') {
                 tileClass += " bg-[var(--color-tile-correct)]";
              } else if (state === 'present') {
                 tileClass += " bg-[var(--color-tile-present)]";
              } else if (state === 'absent') {
                 tileClass += " bg-[var(--color-tile-absent)]";
              } else {
                 tileClass += " bg-[var(--color-tile-empty)]";
                 if (isPending) {
                     if (i === currentRow + 1) tileClass += " opacity-50";
                     else if (i === currentRow + 2) tileClass += " opacity-30";
                     else tileClass += " opacity-20";
                 }
              }

              return (
                <motion.div
                  key={`${i}-${j}`}
                  layout
                  initial={guess ? { scale: 0.9, opacity: 0.5 } : { scale: 1, opacity: 1 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ 
                    layout: { type: "spring", stiffness: 400, damping: 30 },
                    duration: 0.2 
                  }}
                  className={tileClass}
                  style={guess ? { transitionDelay: `${j * 0.05}s` } : {}}
                >
                  {letter}
                </motion.div>
              );
            })}
            {isCurrentRow && (
              <motion.div layout className="absolute -top-3 -right-3 bg-red-500 text-[10px] px-2 py-1 rounded-full font-bold animate-pulse text-white">VOTING</motion.div>
            )}
          </motion.div>
        );
      })}
    </motion.div>
  );
}
